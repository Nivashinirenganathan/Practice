package in.amazon.RestAssururedDemo;

import java.util.HashMap;

import org.junit.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PUTBearerToken {
	
HashMap<String, String> map = new HashMap<String, String>();
	
	@BeforeMethod
	public void createPayLoad() {
		map.put("name","Supermannn");
		map.put("email", "superman1554466@gmail.com");
		map.put("gender", "male");
		map.put("status", "active");
		RestAssured.baseURI = "https://gorest.co.in/";
		RestAssured.basePath = "public/v2/users/4494997";

}
	
	@Test
	
	public void updateResource() {
		Response response = RestAssured //extract the response and save it in the variable called response
		  .given()
		     .contentType("application/json")
		     .header("Authorization", "Bearer d43949f234081289876f55cb97c915afd8a5f9b9bf2d829acb0e92733583380c")
		     .body(map)
		  .when()
		     .put()
		  .then()
		     .extract().response();
		
		JsonPath jsonPath = response.jsonPath();
		Assert.assertTrue(jsonPath.get("name").toString().equals("Supermannn"));
		
	}
}