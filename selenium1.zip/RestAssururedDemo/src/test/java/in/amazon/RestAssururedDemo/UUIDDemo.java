package in.amazon.RestAssururedDemo;

import java.util.HashMap;
import java.util.UUID;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class UUIDDemo {
	
     HashMap<String, String> map = new HashMap<String, String>();
     UUID uuid = UUID.randomUUID();

	
	@BeforeMethod
	public void createPayLoad() {
		map.put("name","Superman");
		map.put("email", uuid+"@gmail.com"); //here if we run the prog again it will show as email id taken or already exists status code 422 soo for changing the mail id everytime we use unique id called as uuid
		map.put("gender", "male");
		map.put("status", "active");
		RestAssured.baseURI = "https://gorest.co.in/";
		RestAssured.basePath = "public/v2/users";
	}
	
	@Test
	public void createRecource() {
		RestAssured
		 .given()
		    .contentType("application/json")
		    .body(map)
		    .header("Authorization" , "Bearer d43949f234081289876f55cb97c915afd8a5f9b9bf2d829acb0e92733583380c")
		 .when()
		    .post()
		 .then()
		    .statusCode(201)
		    .log().all();		
	}

}



