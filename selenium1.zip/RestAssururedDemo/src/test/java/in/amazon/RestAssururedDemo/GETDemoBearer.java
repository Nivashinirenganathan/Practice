package in.amazon.RestAssururedDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class GETDemoBearer {
	
	@Test
	public void verifyResource() {
		RestAssured
		  .given()
		     .contentType("application/json")
		     .header("Authorization", "Bearer d43949f234081289876f55cb97c915afd8a5f9b9bf2d829acb0e92733583380c")
		  .when()
		     .get("https://gorest.co.in/public/v2/users/4494997")
		  .then()
		     .statusCode(200)
		     .log().all();
	}

}
